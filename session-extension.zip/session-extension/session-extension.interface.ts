export interface SessionConfig {
  countdownTime: number;
  userIdleTime: number;
  saveData: () => void;
  logout: () => void;
  logoutOnIdle: () => void;
  getSessionId: () => string;
  getAccessToken: () => string;
}
