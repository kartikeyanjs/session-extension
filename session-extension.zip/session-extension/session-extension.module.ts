import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleWithProviders } from '@angular/compiler/src/core';
import { SessionExtensionService } from './session-extension.service';
import { CONFIG_OPTIONS } from './tokens';
import { environment } from '../../../environments/environment';
import {
  configFactory
} from './session-extension-config';
import { ConfirmDialogService } from './confirm-dialogue/services/confirm-dialog.service';
import { ConfirmDialogComponent } from './confirm-dialogue/confirm-dialogue.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
@NgModule({
  declarations: [ConfirmDialogComponent],
  entryComponents: [ConfirmDialogComponent],
  imports: [CommonModule, MatDialogModule, MatIconModule],
  providers: [
    {
      provide: SessionExtensionService,
    },
    {
      provide: ConfirmDialogService,
    },
  ],
})
export class SessionExtensionModule {
  /**
   *
   * @param countdownTime - It is the countdown time to display on popup
   * @param userIdleTime - It is the time period to track the idle state of the application
   * @param deps - An array of depencies required for configuration
   * @returns ModuleWithProviders
   */
  static configure(
    countdownTime: number,
    userIdleTime: number,
    deps: Array<object>
  ): ModuleWithProviders {
    return {
      ngModule: SessionExtensionModule,
      providers: [
        { provide: 'ENVIRONMENT', useValue: environment },
        {
          provide: CONFIG_OPTIONS,
          useFactory: configFactory(countdownTime, userIdleTime),
          deps,
        },
      ],
    };
  }
}
