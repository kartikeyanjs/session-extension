import { HttpClient } from "@angular/common/http";
import { discardPeriodicTasks, fakeAsync, TestBed, tick } from "@angular/core/testing";
import { CookieService } from "ngx-cookie-service";
import { of, Subject, Subscription } from "rxjs";
import { DataService } from "../../helpers/services/data.service";
import { ConfirmDialogService } from "./confirm-dialogue/services/confirm-dialog.service";
import { CONFIG_OPTIONS } from "./tokens";

import { SessionExtensionService } from './session-extension.service';

describe('SessionWatcherService', () => {
  let service: SessionExtensionService;
  let localStore;
  let confirmDialogueService: ConfirmDialogService;
  const dataServiceStub = {
    getRoleMapping: () => {},
    setModuleSaveData: () => {},
    saveModuleSubject: new Subject<any>()
  };
  const cookieServiceStub = {
    get: (id) => {
      if (id === 'access_token') {
        return 'eyJraWQiOiJBYkhpYmJJQlFGOFhxbEtXOEVWSFNhSjBRYWdYenVqNERndmczUUVENkMwIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULkFmSnNjbmJpS3lTejl2b3ZrQ0pVNWNJeXFRbGlyYWZmTXpaQWhiR1JsbjQub2FyMXJ2dGEwZlJkYlBLT2gwaDciLCJpc3MiOiJodHRwczovL21hcnNoZGV2LW1tYy5va3RhcHJldmlldy5jb20vb2F1dGgyL2RlZmF1bHQiLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjYyNDg5MjM2LCJleHAiOjE2NjI0OTY0MzYsImNpZCI6IjBvYXZ1Mjk3NTBEWGVEQWVlMGg3IiwidWlkIjoiMDB1MTd3bThhNTIwWU5DRDcwaDgiLCJzY3AiOlsib2ZmbGluZV9hY2Nlc3MiLCJncm91cHMiLCJwcm9maWxlIiwib3BlbmlkIl0sImF1dGhfdGltZSI6MTY2MjQ4OTIzNCwic3ViIjoiMTI2ODAyNUBhZC51cy5tcnNobWMuY29tIn0.ptWZx0vfTizqe2yqj1Ddlm_w0HyNCj9g9w7tLBmbed3TbTSmoKVRe-GxfKzzUNnl55v8uOuMg2fZlevsaeWQlrUmn5E-Ov6tfDcx1hsD44pWxUm98w6MEQS9VNNM8TUBFqgbDV6kjzlnhnGsNLyp_zCzE1qthimBMjB6l8raYO7c2_oPVj6dgoXngOaXEx_qzdG_dmWBnwL8kZcvOeMqPwgsPiwvSzw_cu8esxYKqmiPyLHY93HLNBYOvEl_Rmrks_lPGJ6RtJBKWIzJHnVwFXyZI3q2HxKfI5UYdZysy9-57caj3KzepQiLs_nPTUM1zNrQE7ldvndHvBJawq8AMg';
      }
      if (id === 'session_id') {
        return 'DQjto0rjpbRr8P4Hyh0crQUjHKuBZFgE'
      }
    }
  };
  const confirmDialogueServiceStub = {
    open: () => {},
    confirmed: () => {
      return of (true);
    },
    dialogRef: {
      componentInstance: {
        data: {
          message: ''
        }
      },
      close: () => {}
    },
    openDialogue: () => {},
    sessionExpired: true
  };
  const configStub = {
    logoutOnIdle: () => {},
    getAccessToken: () => {},
    getSessionId: () => {},
    logOutSuccess: () => {},
    logout: () => {},
    saveData: () => {},
    userIdleTime: 60,
  }
  const httpClientSpy = jasmine.createSpyObj('HttpClient', ['post', 'get']);
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      providers: [
        { provide: ConfirmDialogService, useValue: confirmDialogueServiceStub },
        { provide: SessionExtensionService },
        { provide: CookieService, useValue: cookieServiceStub },
        { provide: HttpClient, useValue: httpClientSpy },
        { provide: CONFIG_OPTIONS, useValue: configStub },
      ],
    });
    service = TestBed.inject(SessionExtensionService);
    confirmDialogueService = TestBed.inject(ConfirmDialogService);
    localStore = {};
    spyOn(window.localStorage, 'getItem').and.callFake((key) =>
      key in localStore ? localStore[key] : null
    );
    spyOn(window.localStorage, 'setItem').and.callFake(
      (key, value) => (localStore[key] = value + '')
    );
    spyOn(window.localStorage, 'clear').and.callFake(() => (localStore = {}));
    (service as any).timer$ = new Subscription();
    (service as any).idleSubscription$ = new Subscription();
    (service as any).storageSubscription$ = new Subscription();
  });
  describe('getRefreshToken', () => {
    httpClientSpy.get.and.returnValue(
      of(
        {
          status: 200,
          data: {
            access_token: 'adfedscsd-dsdsdsd-dsds',
            time_remaining: 120
          }
        }
      )
    );
    it('it should call getRefreshToken on not local', fakeAsync(() => {
      service.environment.envName = 'development';
      const extendUserSession = spyOn(service, 'extendUserSession');
      service.getRefreshToken();
      tick();
      expect(extendUserSession).toHaveBeenCalled();
    }));
    it('it should call getRefreshToken on local', fakeAsync(() => {
      service.environment.envName = 'local';
      const extendUserSession = spyOn(service, 'extendUserSession');
      service.getRefreshToken();
      tick();
      expect(extendUserSession).toHaveBeenCalled();
    }));
  });
  describe('initDialogueCloseSubscription', () => {
    it('confirm dialog on logout', () => {
      confirmDialogueService.sessionExpired = false;
      const logout = spyOn(configStub, 'logout');
      spyOn(confirmDialogueService, 'confirmed').and.callFake(
        () => of(false)
      );
      service.initDialogueCloseSubscription();
      expect(logout).toHaveBeenCalled();
    });
    it('it should call initDialogueCloseSubscription', () => {
      spyOn(confirmDialogueService, 'confirmed').and.callFake(
        () => of(true)
      );
      const refreshToken = spyOn(service, 'getRefreshToken');
      service.initDialogueCloseSubscription();
      expect(refreshToken).toHaveBeenCalled();
    });
  });
  it('it should call onUserIdle', () => {
    const openDialogue = spyOn(confirmDialogueService, 'openDialogue').and.callThrough();
    const initDialogueCloseSubscription = spyOn(service, 'initDialogueCloseSubscription');
    service.onUserIdle();
    expect(openDialogue).toHaveBeenCalled();
    expect(initDialogueCloseSubscription).toHaveBeenCalled();
  });
  it('it should call initUserIdleSubscription', () => {
    const spy = spyOn(service, 'onIdle').and.callThrough();
    service.initUserIdleSubscription(120);
    expect(spy).toHaveBeenCalled();
  })
  xit('it should call wasUserIdle', fakeAsync( () => {
    const saveModule = spyOn(configStub, 'saveData').and.callThrough();
    const refreshToken = spyOn(service, 'getRefreshToken').and.callFake(()=>{
      return undefined;
    })
    const onUserIdle = spyOn(service, 'onUserIdle');
    service.userIdle = false;
    service.wasUserIdle();
    tick(61000);
    expect(refreshToken).toHaveBeenCalled();
    expect(saveModule).toHaveBeenCalled();
    discardPeriodicTasks();
    service.userIdle = true;
    service.wasUserIdle();
    tick(61000);
    expect(onUserIdle).toHaveBeenCalled();
    expect(saveModule).toHaveBeenCalled();
    discardPeriodicTasks();
  }));
  xit('it should call extendUserSession', fakeAsync(() => {
    const initUserIdleSubscription = spyOn(service, 'initUserIdleSubscription');
    const wasUserIdle = spyOn(service, 'wasUserIdle');
    service.extendUserSession(120);
    tick(60000);
    expect(initUserIdleSubscription).toHaveBeenCalled();
    expect(wasUserIdle).toHaveBeenCalled();
    discardPeriodicTasks();
    service.extendUserSession(120);
    tick(60000);
    discardPeriodicTasks();
  }));
  it('it should create service', () => {
    expect(service).toBeTruthy();
  });
  it('should create createLastActiveTime', () => {
    service['createLastActiveTime'](Math.floor(Date.now() / 1000));
    expect(localStorage.getItem('lastActiveTime')).toBeDefined();
  });
  it('should call resetTimer', () => {
    const startTimer = spyOn<any>(service, 'startTimer');
    service.resetTimer();
    expect(startTimer).toHaveBeenCalled();
  });
  it('should call stopTimer', () => {
    const timer = spyOn<any>((service as any).timer$, 'unsubscribe');
    const idleSubscription = spyOn<any>((service as any).idleSubscription$, 'unsubscribe');
    const storageSubscription = spyOn<any>((service as any).storageSubscription$, 'unsubscribe');
    service.stopTimer();
    expect(timer).toHaveBeenCalled();
    expect(idleSubscription).toHaveBeenCalled();
    expect(storageSubscription).toHaveBeenCalled();
  });
  it('should call onLocalStorageEvent', () => {
    (service as any).onLocalStorageEvent();
    const resetTimer = spyOn(service, 'resetTimer').and.callThrough();
    const storage = new StorageEvent('storage', {
      key: 'lastActiveTime',
      newValue: 'test_value',
      storageArea: localStorage
    });
    window.dispatchEvent(storage);
    expect(resetTimer).toHaveBeenCalled();
  });
  describe('onIdle', () => {
    it('should call onIdle', () => {
      const startTimer = spyOn<any>(service, 'startTimer');
      const onLocalStorageEvent = spyOn<any>(service, 'onLocalStorageEvent');
      service.onIdle(60);
      const createLastActiveTime = spyOn<any>(service, 'createLastActiveTime').and.callThrough();
      const resetTimer = spyOn(service, 'resetTimer').and.callThrough();
      const event = new MouseEvent('mousemove');
      window.dispatchEvent(event);
      expect(startTimer).toHaveBeenCalled();
      expect(resetTimer).toHaveBeenCalled();
      expect(createLastActiveTime).toHaveBeenCalled();
      expect(onLocalStorageEvent).toHaveBeenCalled();
    });
  });
  it('should call startTimer', fakeAsync(() => {
    (service as any).timeOutMilliSeconds = 100;
    (service as any).startTimer();
    tick(100);
    expect(service.userIdle).toBeTrue();
    discardPeriodicTasks();
  }));
});
