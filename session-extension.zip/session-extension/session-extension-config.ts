import { DataService } from '../../helpers/services/data.service';
import { AuthService } from '../auth/services/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { SessionConfig } from './session-extension.interface';
/**
 * Configuration for session extension module
 * @returns config object
 */
export function configFactory(countdownTime: number, userIdleTime: number): any {
  return (
    dataService: DataService,
    authService: AuthService,
    cookieService: CookieService,
  ): SessionConfig => {
    return {
      /**
       * It is the countdown time to display on popup
       */
      countdownTime,
      /**
       * It is the time period to track the idle state of the application
       */
      userIdleTime,
      /**
       * This method is exectued during the detection of
       *  app idle state
       */
      saveData: () => {
        dataService.setModuleSaveData(true);
        dataService.saveModuleSubject.next(null);
      },
      /**
       * Executed when the user clicks on logout button
       * of the popup
       */
      logout: () => {
        authService.logout();
      },
      /**
       * Executed when the countdown is completed.
       * We may want to clear the session redirect
       * the user to a welcome page
       */
      logoutOnIdle: () => {
        authService.logoutOnIdle();
      },
      /**
       * Gets session ID from the cookies
       * @returns session ID
       */
      getSessionId: () => {
        return cookieService.get('session_id');
      },
      /**
       * Gets access token from the cookies
       * @returns access token
       */
      getAccessToken: () => {
        return cookieService.get('access_token');
      }
    };
  };
}
