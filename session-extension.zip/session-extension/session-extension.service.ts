import { Inject, Injectable } from '@angular/core';
import { setTimeout } from 'worker-timers';
import {
  Observable,
  fromEvent,
  merge,
  Subject,
  timer,
  Subscription,
} from 'rxjs';
import { tap, first, filter } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { ConfirmDialogService } from './confirm-dialogue/services/confirm-dialog.service';
import { SessionConfig } from './session-extension.interface';
import { CONFIG_OPTIONS } from './tokens';
@Injectable()
export class SessionExtensionService {
  private idle$: Observable<Event>;
  private storage$: Observable<Event>;
  private timeOutMilliSeconds: number;
  private idleSubscription$: Subscription = Subscription.EMPTY;
  private storageSubscription$: Subscription = Subscription.EMPTY;
  private timer$: Subscription = Subscription.EMPTY;
  public userIdle = true;
  sessionExtensionTimeout: any;
  userIdleTimeout: any;
  throttleTimeout: any;
  environment = environment;
  public expired$: Subject<boolean> = new Subject<boolean>();
  constructor(
    private readonly http: HttpClient,
    @Inject(CONFIG_OPTIONS) private readonly config: SessionConfig,
    private confirmDialogueService: ConfirmDialogService
  ) {}

  public onIdle(timeOutSeconds: number): Observable<any> {
    this.onLocalStorageEvent();
    this.idle$ = merge(
      fromEvent(document, 'mousemove'),
      fromEvent(document, 'click'),
      fromEvent(document, 'mousedown'),
      fromEvent(document, 'keypress'),
      fromEvent(document, 'DOMMouseScroll'),
      fromEvent(document, 'mousewheel'),
      fromEvent(document, 'touchmove'),
      fromEvent(document, 'MSPointerMove'),
      fromEvent(window, 'mousemove'),
      fromEvent(window, 'resize')
    );
    this.timeOutMilliSeconds = timeOutSeconds * 1000;
    this.idleSubscription$ = this.idle$.subscribe((res) => {
      this.createLastActiveTime(Math.floor(Date.now() / 1000));
      this.resetTimer();
    });
    this.startTimer();
    return this.expired$;
  }

  public getRefreshToken(): void {
    const headers = new HttpHeaders()
      .set('sessionid', this.config.getSessionId())
      .set('Authorization', `Bearer ${this.config.getAccessToken()}`);
    let refreshTokenURL: string;
    if (this.environment.envName === 'local') {
      refreshTokenURL = `/auth/token/refresh`;
    } else {
      refreshTokenURL = `${window.location.origin}/auth/token/refresh`;
    }
    this.http
      .get(refreshTokenURL, { headers })
      .pipe(
        first(),
        tap((data: { access_token: string; time_remaining: number }) => {
          this.extendUserSession(data.time_remaining);
        })
      )
      .subscribe();
  }

  /**
   * Called when the expiry time is less than the user idle time
   * Breaks all the existing timeout and calls the refresh token in a setTimeOut
   * @param expiryTime expiry time from refresh token
   */
  private onThrottleTime(expiryTime): void {
    if (this.throttleTimeout) {
      clearTimeout(this.throttleTimeout);
    }
    this.throttleTimeout = setTimeout(() => {
      this.config.saveData();
      this.getRefreshToken();
    }, expiryTime * 1000);
  }

  /**
   *
   * @param expiryTime is the expiry time from the refresh token API
   */
  public extendUserSession(expiryTime: number): void {
    /**
     * User reloaded the page when token expiry time is less than
     * the user idle time
     */
    if (expiryTime < this.config.userIdleTime) {
      this.onThrottleTime(expiryTime);
      return;
    }
    this.userIdle = true;
    if (this.sessionExtensionTimeout) {
      clearTimeout(this.sessionExtensionTimeout);
    }
    this.sessionExtensionTimeout = setTimeout(() => {
      this.initUserIdleSubscription(this.config.userIdleTime);
      this.wasUserIdle();
    }, (expiryTime - this.config.userIdleTime) * 1000);
  }

  /**
   * Checks if the user was idle
   * If the user was idle, it shows the dialogue
   * or it extends the token
   */
  wasUserIdle(): void {
    if (this.userIdleTimeout) {
      clearTimeout(this.userIdleTimeout);
    }
    this.userIdleTimeout = setTimeout(() => {
      this.stopTimer();
      this.config.saveData();
      if (this.userIdle) {
        this.onUserIdle();
        return;
      }
      this.getRefreshToken();
    }, this.config.userIdleTime * 1000 + 1000);
  }

  onUserIdle(): void {
    const options = {
      title: 'Are you idle?',
      message: `Your session will expire in 5 minutes : 0 seconds`,
      cancelText: 'LOGOUT',
      confirmText: 'YES, CONTINUE',
    };
    this.confirmDialogueService.openDialogue(options);
    this.initDialogueCloseSubscription();
  }

  initDialogueCloseSubscription(): void {
    this.confirmDialogueService
      .confirmed()
      .pipe(first())
      .subscribe((confirmed) => {
        if (confirmed) {
          this.getRefreshToken();
          clearInterval(this.confirmDialogueService.countDownTimer);
          return;
        }
        if (this.confirmDialogueService.sessionExpired) {
          this.confirmDialogueService.sessionExpired = false;
          return;
        }
        this.config.logout();
      });
  }

  /**
   * Subscription to watch user activity
   * @param timeOutSeconds is the no of seconds to watch user activity
   */
  initUserIdleSubscription(timeOutSeconds): void {
    this.onIdle(timeOutSeconds).pipe(first()).subscribe();
  }

  private onLocalStorageEvent(): void {
    this.storage$ = fromEvent<StorageEvent>(window, 'storage').pipe(
      filter((event) => event.storageArea === localStorage),
      filter((event) => {
        return event.key === 'lastActiveTime';
      })
    );
    this.storageSubscription$ = this.storage$.subscribe(() => {
      this.resetTimer();
    });
  }
  /**
   * Stores the lastActive time in the local storage
   * @param time gets the timestamp in milliseconds
   */
  private createLastActiveTime(time): void {
    localStorage.setItem('lastActiveTime', time);
  }

  private startTimer(): void {
    this.timer$ = timer(
      this.timeOutMilliSeconds,
      this.timeOutMilliSeconds
    ).subscribe((res) => {
      this.userIdle = true;
      this.expired$.next(true);
    });
  }

  public resetTimer(): void {
    this.userIdle = false;
    this.timer$.unsubscribe();
    this.startTimer();
  }

  public stopTimer(): void {
    this.timer$.unsubscribe();
    this.idleSubscription$.unsubscribe();
    this.storageSubscription$.unsubscribe();
  }
}
