import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfirmDialogComponent } from './confirm-dialogue.component';

describe('ConfirmDialogComponent', () => {
  let component: ConfirmDialogComponent;
  let fixture: ComponentFixture<ConfirmDialogComponent>;
  const dialogRef = {
    close: () => {}
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ConfirmDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: dialogRef },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call onEsc', () => {
    const spy = spyOn(component, 'close').and.callThrough();
    component.onEsc();
    expect(spy).toHaveBeenCalled();
  });

  it('should call extend', () => {
    const spy = spyOn(component, 'close').and.callThrough();
    component.extend();
    expect(spy).toHaveBeenCalled();
  });

  it('should call cancel', () => {
    const spy = spyOn(component, 'close').and.callThrough();
    component.cancel();
    expect(spy).toHaveBeenCalled();
  });

  it('should call close', () => {
    const spy = spyOn(dialogRef, 'close').and.callThrough();
    component.close(true);
    expect(spy).toHaveBeenCalled();
  });
});
