import { Inject, Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { CONFIG_OPTIONS } from '../../tokens';
import { SessionConfig } from '../../session-extension.interface';
import { setInterval } from 'worker-timers';
import { ConfirmDialogComponent } from '../confirm-dialogue.component';
@Injectable()
export class ConfirmDialogService {
  constructor(
    private readonly dialog: MatDialog,
    @Inject(CONFIG_OPTIONS) private readonly config: SessionConfig
  ) {
      this.time = config.countdownTime;
  }
  dialogRef: MatDialogRef<ConfirmDialogComponent>;
  private time: number;
  sessionExpired = false;
  countDownTimer: any;
  public open(options): void {
    this.dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: options.title,
        message: options.message,
        cancelText: options.cancelText,
        confirmText: options.confirmText
      }
    });
  }

  public confirmed(): Observable<any> {
    return this.dialogRef.afterClosed().pipe(take(1), map(res => res));
  }

  startCountdown(): void {
    if (this.countDownTimer) {
      clearInterval(this.countDownTimer);
    }
    this.countDownTimer = setInterval( () => {
      this.updateCountdown();
    }, 1000);
  }

  updateCountdown(): void {
    const minutes = Math.floor(this.time / 60);
    const seconds = this.time % 60;
    const mins = minutes ? 'minutes' : 'minute';
    const displayTime = `${minutes} ${mins} : ${seconds} seconds`;
    this.time--;
    this.dialogRef.componentInstance.data.message = `Your session will expire in ${displayTime}`;
    if (!minutes && !seconds) {
      clearInterval(this.countDownTimer);
      this.sessionExpired = true;
      this.dialogRef.close();
      this.config.logoutOnIdle();
    }
  }

  openDialogue(options: {
    title: string;
    message: string;
    cancelText: string;
    confirmText: string;
  }): void {
    this.open(options);
    this.time = this.config.countdownTime;
    this.startCountdown();
  }

}
