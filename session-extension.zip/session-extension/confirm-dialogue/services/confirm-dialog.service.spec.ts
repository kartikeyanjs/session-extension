import { TestBed } from "@angular/core/testing";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { CONFIG_OPTIONS } from "../../tokens";

import { ConfirmDialogService } from './confirm-dialog.service';

describe('ConfirmDialogService', () => {
  let service: ConfirmDialogService;
  let dialog: MatDialog;
  const dialogRef = {
    close: () => {}
  };
  const configStub = {
    logoutOnIdle: () => {},
    getAccessToken: () => {},
    getSessionId: () => {},
    logOutSuccess: () => {},
    logout: () => {},
    saveData: () => {},
    userIdleTime: 60,
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      providers: [
        { provide: MatDialogRef, useValue: dialogRef },
        { provide: ConfirmDialogService},
        { provide: MatDialog, useValue: {
          open: () => {}
        }},
        { provide: CONFIG_OPTIONS, useValue: configStub },
      ]
    });
    service = TestBed.inject(ConfirmDialogService);
    dialog = TestBed.inject(MatDialog);
  });

  it('it should create service', () => {
    expect(service).toBeTruthy();
  });

  it('it should call open', () => {
    const spy = spyOn(dialog, 'open');
    service.open({
      title: 'test',
      message: 'test',
      cancelText: 'test',
      confirmText: 'test'
    });
    expect(spy).toHaveBeenCalled();
  });
});
